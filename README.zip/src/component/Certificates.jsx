// import React from 'react'
// import imgCalander from '../img/schedule_3652191.png'

// function Certificates() {
//   return (
//     <div className='min-h-screen font-[roboto] bg-[#E0C9E9]'>

//       <div>
//         <img className=' h-14 w-14' src="https://s3-alpha-sig.figma.com/img/3fc6/da0f/20c0e38ffda019b46ada182ada7e25fd?Expires=1722211200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=SdBZ-91m0bxchPzoQSLn-N5kqbdfYiu35RwtmJOh5nZPTOT-2EbLEd7TJsQnCFvj1umIrnu-o1CN2WWhwqhG1IxwD-~G~K2Nr707WyjzlnwpJ6-VDf~H5vDL8I0-zzLZPjb4X2dRe6Xhq0H214aJRVOiiMP9LcDdxCtPY71qjRPeBtB~eeiNNbe6OojwNvSz3jCmznvJbBq-M0Jx8gtT8eqixPUVgNV7MxFhv3AGwuxgteQlO5mqRS7BLL9FkqJ0O4-KBtQbPKnsQOJfy9j9Sj3WxghKVhIe5ux1PU3rH8yjUXmQu3LggnsQ7EYM68WIxvX5htN7EyVkqvYW6uxgkg__" alt="error" loading='lazy' title='img1' />
//         <h4>ID Card</h4>
//       </div>
//       <div>
//         <img className=' h-14 w-14' src="https://s3-alpha-sig.figma.com/img/122e/25ae/1efc85de7d93ebcc0bf6dd40d04e5483?Expires=1722211200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=dauOuEmUXLkC5c0eiXvjcNlSq2x9urdlmwboDfs-7mOjHsi3t09MxrHbSImEBqX-388INCVn17SGHYX6zONlbu0gRgY8ffXBoWwROJEXrYQvDtMnNwc5lnZ0-4bq8Ai3pkJ-aLJR6KUZHwYevTyhOzxDLQdxEY2OaCJi6Q9Cjv4CxyScm5H8FPNpqvHFXgeUEutIk7OteMyEFC-WKIifx55jgBS~AWnfAANiH6tT9TdKsc4YfYgDMUnp2moUrKdkxsaicXyUddAD4skrHeHfpIQUV3E5UMQZpOpMrfWiXI2Bi4m1SBA1sqM0zfEDRY-dr31sJhWlITGfZ-6pXTDoVQ__" alt="error" loading='lazy' title='img2' />
//         <h4>Leaving Certificate</h4>
//       </div>
//       <div>
//         <img className=' h-14 w-14' src="https://s3-alpha-sig.figma.com/img/13a6/fa0a/4bf1fc17a74650e52f7af8c567dd305a?Expires=1722211200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=cR6BwSkzdzDtpH9eNmDtv-KfWkneRo~BKPcW0T~OM16l6PHHG22NhgNSYAPRY2xD36Ak~2G833n0QXGeHb7X9bWql4o2KOZ1z8nhJTHKadtURqXMYb~XGuA-62LfU~cTf0X1PGGg6FA6sTX~vuAqUyIuMfLM0AHhomvmJ8~AHfWxaK4hhf3HM~-6rzrcU0tr2pcWwdqghBw8gg4aX~yD~Q254X3GWe5eaUbebUEgKUQ-IORKJ8aIDPpSs86cpuybe70VO8Ci1Imt83iJUvNzvSFGojnHJosgwUbAh9bNv3rhH4q1Jgb~tnIj8qKeXG0nLPOz1HjKoYwbiTOUQpWkTQ__" alt="error" loading='lazy' title='img2' />
//         <h4>Bonafide</h4>
//       </div>
//       <div>
//         <img className=' h-14 w-14' src="https://s3-alpha-sig.figma.com/img/19b7/ef6c/afebe69c5b9af230db846ee4fbc98baf?Expires=1722211200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=AFHV~fsLeJXiDpcGlxecsPk95ucxyVefrELHkcv3I40973A3wrLanAaaiquXBVNIeBjoDX7Xf2ATE9EQEDtLA2082gOuFHsn-ZN-RFyXiNJR3NcJa3LxQuq345FTOanw6sBfqKS8lURTpXfQ2TD4btdYXgB6W83jDxm42bxZOf9AnB7M9H-daY05q7btfHqIVoXklsDDxmXGsM3OxpyECc4-L4YdTmNOAsdY-lFJiokckHvUYy4AMZYD6m6PYY0FMhQkyoeuXt451tSdo1~5fc7PE3FFVZMlPG0DNe0BwEmyeY2oQk9Bb31Xtn5MNkS08KAL1PaupRvCHb3OHDMzUA__" alt="error" loading='lazy' title='img2' />


//         <h4>Nirgam Certificate</h4>
//       </div>

//       <div>
//         <img className=' h-14 w-14' src="https://s3-alpha-sig.figma.com/img/13a6/fa0a/4bf1fc17a74650e52f7af8c567dd305a?Expires=1722211200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=cR6BwSkzdzDtpH9eNmDtv-KfWkneRo~BKPcW0T~OM16l6PHHG22NhgNSYAPRY2xD36Ak~2G833n0QXGeHb7X9bWql4o2KOZ1z8nhJTHKadtURqXMYb~XGuA-62LfU~cTf0X1PGGg6FA6sTX~vuAqUyIuMfLM0AHhomvmJ8~AHfWxaK4hhf3HM~-6rzrcU0tr2pcWwdqghBw8gg4aX~yD~Q254X3GWe5eaUbebUEgKUQ-IORKJ8aIDPpSs86cpuybe70VO8Ci1Imt83iJUvNzvSFGojnHJosgwUbAh9bNv3rhH4q1Jgb~tnIj8qKeXG0nLPOz1HjKoYwbiTOUQpWkTQ__" alt="error" loading='lazy' title='img2' />


//         <h4>Fees Payment</h4>
//       </div>
//       <div>
//         <img className=' h-14 w-14' src={imgCalander} alt="error" loading='lazy' title='img2' />


//         <h4>Attendence</h4>
//       </div>
//     </div>
//   )
// }

// export default Certificates




















import React from 'react'
import imgCalander from '../img/schedule_3652191.png'

function Certificates() {
  const certificates = [
    { imgSrc: "https://s3-alpha-sig.figma.com/img/3fc6/da0f/20c0e38ffda019b46ada182ada7e25fd?Expires=1722211200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=SdBZ-91m0bxchPzoQSLn-N5kqbdfYiu35RwtmJOh5nZPTOT-2EbLEd7TJsQnCFvj1umIrnu-o1CN2WWhwqhG1IxwD-~G~K2Nr707WyjzlnwpJ6-VDf~H5vDL8I0-zzLZPjb4X2dRe6Xhq0H214aJRVOiiMP9LcDdxCtPY71qjRPeBtB~eeiNNbe6OojwNvSz3jCmznvJbBq-M0Jx8gtT8eqixPUVgNV7MxFhv3AGwuxgteQlO5mqRS7BLL9FkqJ0O4-KBtQbPKnsQOJfy9j9Sj3WxghKVhIe5ux1PU3rH8yjUXmQu3LggnsQ7EYM68WIxvX5htN7EyVkqvYW6uxgkg__", title: "ID Card" },
    { imgSrc: "https://s3-alpha-sig.figma.com/img/122e/25ae/1efc85de7d93ebcc0bf6dd40d04e5483?Expires=1722211200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=dauOuEmUXLkC5c0eiXvjcNlSq2x9urdlmwboDfs-7mOjHsi3t09MxrHbSImEBqX-388INCVn17SGHYX6zONlbu0gRgY8ffXBoWwROJEXrYQvDtMnNwc5lnZ0-4bq8Ai3pkJ-aLJR6KUZHwYevTyhOzxDLQdxEY2OaCJi6Q9Cjv4CxyScm5H8FPNpqvHFXgeUEutIk7OteMyEFC-WKIifx55jgBS~AWnfAANiH6tT9TdKsc4YfYgDMUnp2moUrKdkxsaicXyUddAD4skrHeHfpIQUV3E5UMQZpOpMrfWiXI2Bi4m1SBA1sqM0zfEDRY-dr31sJhWlITGfZ-6pXTDoVQ__", title: "Leaving Certificate" },
    { imgSrc: "https://s3-alpha-sig.figma.com/img/13a6/fa0a/4bf1fc17a74650e52f7af8c567dd305a?Expires=1722211200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=cR6BwSkzdzDtpH9eNmDtv-KfWkneRo~BKPcW0T~OM16l6PHHG22NhgNSYAPRY2xD36Ak~2G833n0QXGeHb7X9bWql4o2KOZ1z8nhJTHKadtURqXMYb~XGuA-62LfU~cTf0X1PGGg6FA6sTX~vuAqUyIuMfLM0AHhomvmJ8~AHfWxaK4hhf3HM~-6rzrcU0tr2pcWwdqghBw8gg4aX~yD~Q254X3GWe5eaUbebUEgKUQ-IORKJ8aIDPpSs86cpuybe70VO8Ci1Imt83iJUvNzvSFGojnHJosgwUbAh9bNv3rhH4q1Jgb~tnIj8qKeXG0nLPOz1HjKoYwbiTOUQpWkTQ__", title: "Bonafide" },
    { imgSrc: "https://s3-alpha-sig.figma.com/img/19b7/ef6c/afebe69c5b9af230db846ee4fbc98baf?Expires=1722211200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=AFHV~fsLeJXiDpcGlxecsPk95ucxyVefrELHkcv3I40973A3wrLanAaaiquXBVNIeBjoDX7Xf2ATE9EQEDtLA2082gOuFHsn-ZN-RFyXiNJR3NcJa3LxQuq345FTOanw6sBfqKS8lURTpXfQ2TD4btdYXgB6W83jDxm42bxZOf9AnB7M9H-daY05q7btfHqIVoXklsDDxmXGsM3OxpyECc4-L4YdTmNOAsdY-lFJiokckHvUYy4AMZYD6m6PYY0FMhQkyoeuXt451tSdo1~5fc7PE3FFVZMlPG0DNe0BwEmyeY2oQk9Bb31Xtn5MNkS08KAL1PaupRvCHb3OHDMzUA__", title: "Nirgam Certificate" },
    { imgSrc: "https://s3-alpha-sig.figma.com/img/13a6/fa0a/4bf1fc17a74650e52f7af8c567dd305a?Expires=1722211200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=cR6BwSkzdzDtpH9eNmDtv-KfWkneRo~BKPcW0T~OM16l6PHHG22NhgNSYAPRY2xD36Ak~2G833n0QXGeHb7X9bWql4o2KOZ1z8nhJTHKadtURqXMYb~XGuA-62LfU~cTf0X1PGGg6FA6sTX~vuAqUyIuMfLM0AHhomvmJ8~AHfWxaK4hhf3HM~-6rzrcU0tr2pcWwdqghBw8gg4aX~yD~Q254X3GWe5eaUbebUEgKUQ-IORKJ8aIDPpSs86cpuybe70VO8Ci1Imt83iJUvNzvSFGojnHJosgwUbAh9bNv3rhH4q1Jgb~tnIj8qKeXG0nLPOz1HjKoYwbiTOUQpWkTQ__", title: "Fees Payment" },
    { imgSrc: imgCalander, title: "Attendance" }
  ];

  return (
    <div className="min-h-screen font-[roboto] bg-[#E0C9E9] p-6">
      <div className="grid grid-cols-2 mt-12 p-4 lg:p-12  sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-2 gap-6">
        {certificates.map((certificate, index) => (
          <div key={index} className=" m-4 cursor-pointer rounded-lg shadow-md p-4 flex flex-col items-center">
            <img className="h-14 w-14 mb-4 " src={certificate.imgSrc} alt={certificate.title} loading='lazy' title={certificate.title} />
            <h4 className="text-center text-lg font-medium">{certificate.title}</h4>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Certificates;
